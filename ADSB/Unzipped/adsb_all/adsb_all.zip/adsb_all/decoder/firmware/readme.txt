adsb_11.hex
===========
This is the old but reliable Fw 11.

adsb_12.hex & adsb_14.hex
=========================
These are two new firmware-versions for higher framerate. Both versions are 
optimized for different type of decoder-hardware. You can try both. I expext
the better result with Fw14 on the most decoders. If Fw12 works better on your
hardware, then please report this (sprut@sprut.de) and send a short description
of your hardware.
In future i will merge both designs and add an automatic selection feature.

sprut
