das ist eine Version fuer den adsbPIC-Decoder
mit Abfrage des Jumpers
und Abfrage der EEPROM-Zelle

    0x04D8,                 // Vendor ID
    0xFF0B,                 // Product ID: Sprut

// LEDs h�ngen an RC1 und RC2 
// CCP2 liegt auf RB3

/* Bootloader Version */
#define MINOR_VERSION   0x00    //Bootloader Version 0
#define MAJOR_VERSION   0x01	//Bootloader 
